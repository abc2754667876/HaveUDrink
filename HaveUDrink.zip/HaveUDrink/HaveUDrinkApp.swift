//
//  HaveUDrinkApp.swift
//  HaveUDrink
//
//  Created by Chengzhi 张 on 2024/10/9.
//

import SwiftUI
import UserNotifications

@main
struct HaveUDrinkApp: App {
    init() {
        let openRemind = UserDefaults.standard.bool(forKey: "openRemind")
        if openRemind {
            let remindTime = UserDefaults.standard.integer(forKey: "remindTime")
            let getupTime = UserDefaults.standard.string(forKey: "getupTime")!
            let sleepTime = UserDefaults.standard.string(forKey: "sleepTime")!
            let realGetupTime = adjustDateByMinutes(HourAndMinuteToDate(getupTime)!, minutes: 30)
            let realSleepTime = adjustDateByMinutes(HourAndMinuteToDate(sleepTime)!, minutes: -30)
            let times = generateReminderTimes(start: realGetupTime, end: realSleepTime, interval: remindTime)
            NotificationManager.shared.scheduleNotifications(for: times, title: "饮水提醒", body: "该喝水啦，记得及时饮水哦！")
        }
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
