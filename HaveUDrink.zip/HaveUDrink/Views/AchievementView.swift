//
//  RemindView.swift
//  HaveUDrink
//
//  Created by Chengzhi 张 on 2024/10/13.
//

import SwiftUI

struct AchievementView: View {
    @AppStorage("colorSet") private var colorSet = "defaultColor"
    
    var body: some View {
        NavigationView{
            ZStack{
                Color(.secondarySystemBackground)
                    .ignoresSafeArea()
                
                ScrollView{
                    VStack {
                        HStack{
                            Text("健康饮水")
                                .bold()
                                .font(.system(size: 20))
                            
                            Spacer()
                        }
                        
                        AchievementCard(title: "连续1天饮水合环", progress: Double(DataManager.shared.getMaximumConsecutiveCompletionDay()) / Double(1), achieved: isAchieved(day1: DataManager.shared.getMaximumConsecutiveCompletionDay(), day2: 1), medalName: "finish-1-get")
                        AchievementCard(title: "连续3天饮水合环", progress: Double(DataManager.shared.getMaximumConsecutiveCompletionDay()) / Double(3), achieved: isAchieved(day1: DataManager.shared.getMaximumConsecutiveCompletionDay(), day2: 3), medalName: "finish-3-get")
                        AchievementCard(title: "连续7天饮水合环", progress: Double(DataManager.shared.getMaximumConsecutiveCompletionDay()) / Double(7), achieved: isAchieved(day1: DataManager.shared.getMaximumConsecutiveCompletionDay(), day2: 7), medalName: "finish-7-get")
                        AchievementCard(title: "连续15天饮水合环", progress: Double(DataManager.shared.getMaximumConsecutiveCompletionDay()) / Double(15), achieved: isAchieved(day1: DataManager.shared.getMaximumConsecutiveCompletionDay(), day2: 15), medalName: "finish-15-get")
                        AchievementCard(title: "连续30天饮水合环", progress: Double(DataManager.shared.getMaximumConsecutiveCompletionDay()) / Double(30), achieved: isAchieved(day1: DataManager.shared.getMaximumConsecutiveCompletionDay(), day2: 30), medalName: "finish-30-get")
                        AchievementCard(title: "连续100天饮水合环", progress: Double(DataManager.shared.getMaximumConsecutiveCompletionDay()) / Double(100), achieved: isAchieved(day1: DataManager.shared.getMaximumConsecutiveCompletionDay(), day2: 100), medalName: "finish-100-get")
                        AchievementCard(title: "连续365天饮水合环", progress: Double(DataManager.shared.getMaximumConsecutiveCompletionDay()) / Double(365), achieved: isAchieved(day1: DataManager.shared.getMaximumConsecutiveCompletionDay(), day2: 365), medalName: "finish-365-get")
                        
                        HStack{
                            Text("不饮酒")
                                .bold()
                                .font(.system(size: 20))
                            
                            Spacer()
                        }
                        .padding(.top)
                        
                        AchievementCard(title: "连续1天不摄入酒精", progress: Double(DataManager.shared.getMaximumUnAlcoholDay()) / Double(1), achieved: isAchieved(day1: DataManager.shared.getMaximumUnAlcoholDay(), day2: 1), medalName: "alcohol-1-get")
                        AchievementCard(title: "连续3天不摄入酒精", progress: Double(DataManager.shared.getMaximumUnAlcoholDay()) / Double(3), achieved: isAchieved(day1: DataManager.shared.getMaximumUnAlcoholDay(), day2: 3), medalName: "alcohol-3-get")
                        AchievementCard(title: "连续7天不摄入酒精", progress: Double(DataManager.shared.getMaximumUnAlcoholDay()) / Double(7), achieved: isAchieved(day1: DataManager.shared.getMaximumUnAlcoholDay(), day2: 7), medalName: "alcohol-7-get")
                        AchievementCard(title: "连续15天不摄入酒精", progress: Double(DataManager.shared.getMaximumUnAlcoholDay()) / Double(15), achieved: isAchieved(day1: DataManager.shared.getMaximumUnAlcoholDay(), day2: 15), medalName: "alcohol-15-get")
                        AchievementCard(title: "连续30天不摄入酒精", progress: Double(DataManager.shared.getMaximumUnAlcoholDay()) / Double(30), achieved: isAchieved(day1: DataManager.shared.getMaximumUnAlcoholDay(), day2: 30), medalName: "alcohol-30-get")
                        AchievementCard(title: "连续100天不摄入酒精", progress: Double(DataManager.shared.getMaximumUnAlcoholDay()) / Double(100), achieved: isAchieved(day1: DataManager.shared.getMaximumUnAlcoholDay(), day2: 100), medalName: "alcohol-100-get")
                        AchievementCard(title: "连续365天不摄入酒精", progress: Double(DataManager.shared.getMaximumUnAlcoholDay()) / Double(365), achieved: isAchieved(day1: DataManager.shared.getMaximumUnAlcoholDay(), day2: 365), medalName: "alcohol-365-get")
                        
                        HStack{
                            Text("不喝咖啡")
                                .bold()
                                .font(.system(size: 20))
                            
                            Spacer()
                        }
                        .padding(.top)
                        
                        AchievementCard(title: "连续1天不摄入咖啡因", progress: Double(DataManager.shared.getMaximumUnCoffeeineDay()) / Double(1), achieved: isAchieved(day1: DataManager.shared.getMaximumUnCoffeeineDay(), day2: 1), medalName: "coffeeine-1-get")
                        AchievementCard(title: "连续3天不摄入咖啡因", progress: Double(DataManager.shared.getMaximumUnCoffeeineDay()) / Double(3), achieved: isAchieved(day1: DataManager.shared.getMaximumUnCoffeeineDay(), day2: 3), medalName: "coffeeine-3-get")
                        AchievementCard(title: "连续7天不摄入咖啡因", progress: Double(DataManager.shared.getMaximumUnCoffeeineDay()) / Double(7), achieved: isAchieved(day1: DataManager.shared.getMaximumUnCoffeeineDay(), day2: 7), medalName: "coffeeine-7-get")
                        AchievementCard(title: "连续15天不摄入咖啡因", progress: Double(DataManager.shared.getMaximumUnCoffeeineDay()) / Double(15), achieved: isAchieved(day1: DataManager.shared.getMaximumUnCoffeeineDay(), day2: 15), medalName: "coffeeine-15-get")
                        AchievementCard(title: "连续30天不摄入咖啡因", progress: Double(DataManager.shared.getMaximumUnCoffeeineDay()) / Double(30), achieved: isAchieved(day1: DataManager.shared.getMaximumUnCoffeeineDay(), day2: 30), medalName: "coffeeine-30-get")
                        AchievementCard(title: "连续100天不摄入咖啡因", progress: Double(DataManager.shared.getMaximumUnCoffeeineDay()) / Double(100), achieved: isAchieved(day1: DataManager.shared.getMaximumUnCoffeeineDay(), day2: 100), medalName: "coffeeine-100-get")
                        AchievementCard(title: "连续365天不摄入咖啡因", progress: Double(DataManager.shared.getMaximumUnCoffeeineDay()) / Double(365), achieved: isAchieved(day1: DataManager.shared.getMaximumUnCoffeeineDay(), day2: 365), medalName: "coffeeine-365-get")
                        
                        HStack{
                            Text("不喝奶茶")
                                .bold()
                                .font(.system(size: 20))
                            
                            Spacer()
                        }
                        .padding(.top)
                        
                        AchievementCard(title: "连续1天不喝奶茶", progress: Double(DataManager.shared.getMaximumUnMilkTeaDay()) / Double(1), achieved: isAchieved(day1: DataManager.shared.getMaximumUnMilkTeaDay(), day2: 1), medalName: "milkTea-1-get")
                        AchievementCard(title: "连续3天不喝奶茶", progress: Double(DataManager.shared.getMaximumUnMilkTeaDay()) / Double(3), achieved: isAchieved(day1: DataManager.shared.getMaximumUnMilkTeaDay(), day2: 3), medalName: "milkTea-3-get")
                        AchievementCard(title: "连续7天不喝奶茶", progress: Double(DataManager.shared.getMaximumUnMilkTeaDay()) / Double(7), achieved: isAchieved(day1: DataManager.shared.getMaximumUnMilkTeaDay(), day2: 7), medalName: "milkTea-7-get")
                        AchievementCard(title: "连续15天不喝奶茶", progress: Double(DataManager.shared.getMaximumUnMilkTeaDay()) / Double(15), achieved: isAchieved(day1: DataManager.shared.getMaximumUnMilkTeaDay(), day2: 15), medalName: "milkTea-15-get")
                        AchievementCard(title: "连续30天不喝奶茶", progress: Double(DataManager.shared.getMaximumUnMilkTeaDay()) / Double(30), achieved: isAchieved(day1: DataManager.shared.getMaximumUnMilkTeaDay(), day2: 30), medalName: "milkTea-30-get")
                        AchievementCard(title: "连续100天不喝奶茶", progress: Double(DataManager.shared.getMaximumUnMilkTeaDay()) / Double(100), achieved: isAchieved(day1: DataManager.shared.getMaximumUnMilkTeaDay(), day2: 100), medalName: "milkTea-100-get")
                        AchievementCard(title: "连续365天不喝奶茶", progress: Double(DataManager.shared.getMaximumUnMilkTeaDay()) / Double(365), achieved: isAchieved(day1: DataManager.shared.getMaximumUnMilkTeaDay(), day2: 365), medalName: "milkTea-365-get")
                        
                        HStack{
                            Text("睡前一杯奶")
                                .bold()
                                .font(.system(size: 20))
                            
                            Spacer()
                        }
                        .padding(.top)
                        
                        AchievementCard(title: "连续1天喝牛奶", progress: Double(DataManager.shared.getMaximumMilkDay()) / Double(1), achieved: isAchieved(day1: DataManager.shared.getMaximumMilkDay(), day2: 1), medalName: "milk-1-get")
                        AchievementCard(title: "连续3天喝牛奶", progress: Double(DataManager.shared.getMaximumMilkDay()) / Double(3), achieved: isAchieved(day1: DataManager.shared.getMaximumMilkDay(), day2: 3), medalName: "milk-3-get")
                        AchievementCard(title: "连续7天喝牛奶", progress: Double(DataManager.shared.getMaximumMilkDay()) / Double(7), achieved: isAchieved(day1: DataManager.shared.getMaximumMilkDay(), day2: 7), medalName: "milk-7-get")
                        AchievementCard(title: "连续15天喝牛奶", progress: Double(DataManager.shared.getMaximumMilkDay()) / Double(15), achieved: isAchieved(day1: DataManager.shared.getMaximumMilkDay(), day2: 15), medalName: "milk-15-get")
                        AchievementCard(title: "连续30天喝牛奶", progress: Double(DataManager.shared.getMaximumMilkDay()) / Double(30), achieved: isAchieved(day1: DataManager.shared.getMaximumMilkDay(), day2: 30), medalName: "milk-30-get")
                        AchievementCard(title: "连续100天喝牛奶", progress: Double(DataManager.shared.getMaximumMilkDay()) / Double(100), achieved: isAchieved(day1: DataManager.shared.getMaximumMilkDay(), day2: 100), medalName: "milk-100-get")
                        AchievementCard(title: "连续365天喝牛奶", progress: Double(DataManager.shared.getMaximumMilkDay()) / Double(365), achieved: isAchieved(day1: DataManager.shared.getMaximumMilkDay(), day2: 365), medalName: "milk-365-get")
                        
                        HStack{
                            Text("坚持奖牌")
                                .bold()
                                .font(.system(size: 20))
                            
                            Spacer()
                        }
                        .padding(.top)
                        
                        AchievementCard(title: "连续15天饮水合环且仅饮水", progress: Double(DataManager.shared.getMaximumOnlyWaterDay()) / Double(15), achieved: isAchieved(day1: DataManager.shared.getMaximumOnlyWaterDay(), day2: 15), medalName: "medal_tong")
                        AchievementCard(title: "连续30天饮水合环且仅饮水", progress: Double(DataManager.shared.getMaximumOnlyWaterDay()) / Double(30), achieved: isAchieved(day1: DataManager.shared.getMaximumOnlyWaterDay(), day2: 30), medalName: "medal_yin")
                        AchievementCard(title: "连续60天饮水合环且仅饮水", progress: Double(DataManager.shared.getMaximumOnlyWaterDay()) / Double(60), achieved: isAchieved(day1: DataManager.shared.getMaximumOnlyWaterDay(), day2: 60), medalName: "medal_jin")
                        HStack{
                            Text("*获得坚持金牌后将解锁金色颜色主题")
                                .font(.system(size: 14))
                                .foregroundColor(.gray)
                            
                            Spacer()
                        }
                    }
                    .padding()
                }
                .navigationTitle("成就")
            }
        }
    }
    
    //day1是实际天数，day2是目标天数
    private func isAchieved(day1: Int, day2: Int) -> Bool{
        if day1 >= day2 {
            return true
        } else {
            return false
        }
    }
}

private struct AchievementCard: View {
    @AppStorage("colorSet") private var colorSet = "defaultColor"
    @State private var sealColor = Color(.gray)
    
    var title: String
    var progress: Double
    var achieved: Bool
    var medalName: String
    
    var body: some View {
        HStack{
            if achieved {
                Image(medalName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 60)
                    .padding(.top)
                    .padding(.bottom)
                    .padding(.leading)
            } else {
                Image(medalName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 60)
                    .padding(.top)
                    .padding(.bottom)
                    .padding(.leading)
                    .opacity(0.2)
            }
            
            VStack(alignment: .leading){
                HStack{
                    Text(title)
                        .font(.system(size: 18))
                        .bold()
                        .foregroundStyle(.black)
                    
                    if achieved {
                        Image("medal")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 18)
                    }
                }
                
                CustomProgressBar(progress: progress)
                    .padding(.trailing)
            }
        }
        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/)
        .background(.white)
        .cornerRadius(10)
        .padding(.top, 1)
        .padding(.bottom, 5)
        .onAppear{
            if achieved {
                sealColor = Color(.green)
            } else {
                sealColor = Color(.gray)
            }
        }
    }
}

private struct CustomProgressBar: View {
    @AppStorage("colorSet") private var colorSet = "defaultColor"
    var progress: Double // 进度值，范围从 0.0 到 1.0

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                if progress < 0.99 {
                    RoundedRectangle(cornerRadius: 5)
                        .foregroundColor(Color.gray.opacity(0.1)) // 背景条
                        .frame(height: 20)
                    
                    HStack{
                        RoundedRectangle(cornerRadius: 5)
                            .foregroundColor(Color(colorSet)) // 进度条颜色
                            .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/)
                            .frame(width: geometry.size.width * CGFloat(progress), height: 20)
                            .animation(.easeInOut(duration: 0.5), value: progress) // 动画效果
                        Spacer()
                    }
                } else {
                    RoundedRectangle(cornerRadius: 5)
                        .foregroundColor(Color(colorSet)) // 背景条
                        .frame(height: 20)
                }
            }
        }
        .frame(height: 25) // 整个控件的高度
    }
}

#Preview {
    AchievementView()
}
